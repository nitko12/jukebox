const consts = require("./consts.js");
var sqlite3 = require("sqlite3").verbose();
const uuid = require("uuid/v4");
const bcrypt = require("bcryptjs");

class User {
    constructor(db) {
        this.db = db;
    }

    findByArgs(args, fn) {
        this.db.get(
            `SELECT * FROM "users" WHERE username = ?`,
            args.username,
            (err, row) => {
                if (err) return fn(err);
                bcrypt.compare(args.password, row.password, (err, res) => {
                    if (err) return fn(err);
                    if (res) return fn(null, row);
                    return fn(true);
                });
            }
        );
    }

    findById(id, fn) {
        this.db.get(`SELECT * FROM "users" WHERE id = ?`, id, (err, row) => {
            if (err) return fn(err);
            fn(null, row);
        });
    }

    add(id, args, fn) {
        bcrypt.genSalt(10, (err, salt) => {
            if (err) return console.log(err);
            bcrypt.hash(args.password, salt, (err, hash) => {
                if (err) return console.log(err);
                this.db.run(
                    `INSERT INTO "users" VALUES (?, ?, ?, ?, ?, ?) `,
                    id,
                    args.username,
                    hash,
                    "never",
                    "never",
                    args.raz,
                    fn
                );
            });
        });
    }

    getAll(fn) {
        this.db.all(`SELECT * FROM "users"`, (err, rows) => {
            if (err) return fn(err);
            return fn(err, rows);
        });
    }

    batch(data, fn) {
        // test if usernames distinct
        let set = new Set(),
            cnt = 0;

        let next = () => {
            // all clear
            for (let i in data) {
                this.add(
                    uuid(), {
                        username: data[i].username,
                        password: data[i].password,
                        raz: data[i].god + data[i].raz
                    },
                    err => {
                        if (err) {
                            console.log(err);
                            return fn(true);
                        }
                    }
                );
            }

            fn(null); // done
        };

        for (let i in data) {
            console.log(i);
            set.add(data[i].username);
            this.db.get(
                `SELECT * FROM "users" WHERE username = ?`,
                data[i].username,
                (err, row) => {
                    if (err) {
                        console.log(err);
                        return fn(true);
                    }
                    if (row) return fn(true);
                    ++cnt;
                    if (cnt == Object.keys(data).length) {
                        if (set.size != Object.keys(data).length) return fn(true);
                        next();
                    }
                }
            );
        }
    }

    lastRecommend(id, fn) {
        this.db.get(`SELECT * FROM "users" WHERE id = ?`, id, (err, row) => {
            if (err) return fn(err);
            fn(err, row.lastrecommend);
        });
    }

    lastVote(id, fn) {
        this.db.get(`SELECT * FROM "users" WHERE id = ?`, id, (err, row) => {
            if (err) return fn(err);
            fn(err, row.lastvote);
        });
    }
}

class Recs {
    constructor(db, findUserById) {
        this.db = db;
        this.findUserById = findUserById;
    }

    add(id, url, date, fn) {
        this.db.run(
            `UPDATE "users" SET lastrecommend = ? WHERE id = ?`,
            date,
            id,
            err => {
                if (err) return fn(err);
                this.db.run(
                    `INSERT INTO "recommendations" VALUES (?, ?, ?, ?)`,
                    uuid(),
                    id,
                    url,
                    date,
                    fn
                );
            }
        );
    }

    getAll(fn) {
        this.db.all(`SELECT * FROM "recommendations"`, (err, rows) => {
            if (err) return fn(err);
            let data = [];
            rows.forEach(el => {
                this.findUserById(el.userid, (err, user) => {
                    if (err) return fn(err);
                    data.push({
                        id: el.id,
                        username: user.username,
                        date: el.date,
                        url: el.url
                    });
                    if (data.length == rows.length) {
                        return fn(err, data);
                    }
                });
            });
            if (data.length == rows.length) {
                return fn(err, data);
            }
        });
    }
    remove(id, fn) {
        this.db.run(`DELETE FROM "recommendations" WHERE id = ?`, id, fn);
    }
    get(id, fn) {
        this.db.get(
            `SELECT * FROM "recommendations" WHERE id = ?`,
            id,
            (err, row) => {
                if (err) return fn(err);

                this.findUserById(row.userid, (err, user) => {
                    let data = {
                        id: row.id,
                        username: user.username,
                        date: row.date,
                        url: row.url
                    };
                    fn(null, data);
                });
            }
        );
    }
}

class Schedule {
    constructor(db) {
        this.db = db;
    }

    test(data) {
        // clone of the real playing function
        try {
            let now = new Date();
            let day = (((now.getDay() - 1) % 7) + 7) % 7;

            if (
                data.split("\n").length -
                (data.split("\n")[data.split("\n").length - 1] == "") !=
                7
            )
                return false;

            let plays = data
                .split("\n")[day].substr(4)
                .split(";");
            if (plays[plays.length - 1] == "") plays.pop();

            plays = plays.map(el => {
                let s = el.split("-").map(el => {
                    return el.split(":");
                });
                let start = new Date(),
                    end = new Date();
                start.setMilliseconds(0);
                end.setMilliseconds(0);

                start.setSeconds(0);
                end.setSeconds(0);

                start.setHours(s[0][0]);
                end.setHours(s[1][0]);

                start.setMinutes(s[0][1]);
                end.setMinutes(s[1][1]);

                return [start, end];
            });
            return true;
        } catch (err) {
            return false;
        }
    }

    set(obj, fn) {
        console.log(obj);
        if (!this.test(obj)) return fn("Wrong formatting");
        this.db.run(`UPDATE "schedule" SET json = ? WHERE 1`, obj, fn);
    }

    get(fn) {
        this.db.get(`SELECT * FROM "schedule"`, fn);
    }
}

class Queue {
    constructor(db) {
        this.db = db;
    }

    get(fn) {
        this.db.all(`SELECT * FROM "queue"`, (err, rows) => {
            if (err) return fn(err);
            return fn(null, rows);
        });
    }

    push(url, submittedBy, fn) {
        this.db.run(
            `INSERT INTO "queue" VALUES (?, ?, ?, ?)`,
            uuid(),
            url,
            submittedBy,
            0,
            fn
        );
    }

    vote(id, userId, date, fn) {
        this.db.run(
            `UPDATE "queue" SET votes = votes + 1 WHERE id = ?`,
            id,
            (err, data) => {
                if (err) return fn(err);
                this.db.run(
                    `UPDATE "users" SET lastvote = ? WHERE id = ?`,
                    date,
                    userId,
                    fn
                );
            }
        );
    }

    half(id, fn) {
        this.db.run(`UPDATE "queue" SET votes = votes / 2 WHERE id = ?`, id, fn);
    }

    remove(id, fn) {
        this.db.run(`DELETE FROM "queue" WHERE id = ?`, id, fn);
    }
}

class Db {
    constructor() {
        this.db = new sqlite3.Database("./db.sqlite3");
        this.db.run(
            `CREATE TABLE IF NOT EXISTS "users" (id TEXT, username TEXT UNIQUE, password TEXT, lastrecommend TEXT, lastvote TEXT, class TEXT)`,
            err => {
                if (err) return console.log(err);
                this.db.run(
                    `CREATE TABLE IF NOT EXISTS "recommendations" (id TEXT, userid TEXT, url TEXT, date TEXT)`,
                    err => {
                        if (err) return console.log(err);
                        this.db.run(
                            `CREATE TABLE IF NOT EXISTS "schedule" (id TEXT, json TEXT)`,
                            err => {
                                if (err) return console.log(err);
                                this.db.run(
                                    `CREATE TABLE IF NOT EXISTS "queue" (id TEXT, url TEXT, submittedBy TEXT, votes INTEGER)`,
                                    err => {
                                        if (err) return console.log(err);
                                        this.db.get(`SELECT 1 FROM "schedule"`, (err, row) => {
                                            if (err) return console.log(err);
                                            if (!row)
                                                this.db.run(
                                                    `INSERT INTO "schedule" VALUES (?, ?)`,
                                                    uuid(),
                                                    consts.defaultSchedule
                                                );
                                        });
                                    }
                                );
                            }
                        );
                    }
                );
            }
        );
        this.user = new User(this.db);
        this.recs = new Recs(this.db, this.user.findById);
        this.schedule = new Schedule(this.db);
        this.queue = new Queue(this.db);
    }
}

module.exports = new Db();